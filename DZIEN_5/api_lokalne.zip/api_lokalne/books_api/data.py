from .models import Book

books = [
    Book(id=1, title="1984", author="George Orwell", year=1949, genre="Dystopian"),
    Book(id=2, title="Brave New World", author="Aldous Huxley", year=1932, genre="Science Fiction"),
    Book(id=3, title="To Kill a Mockingbird", author="Harper Lee", year=1960)
]
