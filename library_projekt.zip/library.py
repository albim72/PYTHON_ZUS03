import json

class Library:
    def __init__(self):
        self.books = []

    def add_book(self, book):
        self.books.append(book)

    def search_by_author(self, author):
        return [book for book in self.books if book.author.lower() == author.lower()]

    def search_by_title(self, title):
        return [book for book in self.books if title.lower() in book.title.lower()]

    def list_available_books(self):
        available_books = [book for book in self.books if book.available]
        if not available_books:
            print("No available books in the library.")
        else:
            print("Available books:")
            for book in available_books:
                print(f"- {book}")

    def save_state(self, filename):
        data = []
        for book in self.books:
            book_type = type(book).__name__
            book_data = {
                'type': book_type,
                'title': book.title,
                'author': book.author,
                'year': book.year,
                'available': book.available
            }
            if book_type == 'Ebook':
                book_data['filesize'] = book.filesize
            if book_type == 'Magazine':
                book_data['issue'] = book.issue
            data.append(book_data)

        with open(filename, 'w') as f:
            json.dump(data, f, indent=4)

    def load_state(self, filename):
        from book import Book, Ebook, Magazine
        with open(filename, 'r') as f:
            data = json.load(f)
        self.books = []
        for item in data:
            if item['type'] == 'Book':
                book = Book(item['title'], item['author'], item['year'])
            elif item['type'] == 'Ebook':
                book = Ebook(item['title'], item['author'], item['year'], item['filesize'])
            elif item['type'] == 'Magazine':
                book = Magazine(item['title'], item['author'], item['year'], item['issue'])
            else:
                continue
            book.available = item['available']
            self.books.append(book)