from book import Book, Ebook, Magazine
from user import User
from library import Library

if __name__ == "__main__":
    # Create library
    library = Library()

    # Create books
    book1 = Book("1984", "George Orwell", 1949)
    book2 = Ebook("Digital Fortress", "Dan Brown", 1998, 2.5)
    book3 = Magazine("National Geographic", "Various", 2024, "April")

    # Add books to library
    library.add_book(book1)
    library.add_book(book2)
    library.add_book(book3)

    # Create users
    user1 = User("Alice")
    user2 = User("Bob")

    # List available books
    library.list_available_books()

    # Borrowing books
    user1.borrow_book(book1)
    user2.borrow_book(book1)  # should fail (already borrowed)
    user2.borrow_book(book2)

    # List available books after borrowing
    library.list_available_books()

    # User lists
    user1.list_borrowed_books()
    user2.list_borrowed_books()

    # Search functionality
    print("\nSearch results for author 'Dan Brown':")
    for b in library.search_by_author("Dan Brown"):
        print(b)

    print("\nSearch results for title containing 'National':")
    for b in library.search_by_title("National"):
        print(b)

    # Returning books
    user1.return_book(book1)
    user2.borrow_book(book1)  # now should succeed

    # Final state
    library.list_available_books()

    # Save and load state example
    library.save_state("library_state.json")
    print("\nLibrary state saved to library_state.json")

    # Optional: Uncomment to load state
    # library.load_state("library_state.json")
    # library.list_available_books()
