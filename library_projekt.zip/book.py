class Book:
    def __init__(self, title, author, year):
        self._title = title
        self._author = author
        self._year = year
        self._available = True

    @property
    def title(self):
        return self._title

    @property
    def author(self):
        return self._author

    @property
    def year(self):
        return self._year

    @property
    def available(self):
        return self._available

    @available.setter
    def available(self, value):
        if isinstance(value, bool):
            self._available = value
        else:
            raise ValueError("Available must be a boolean")

    def __str__(self):
        status = "Available" if self._available else "Borrowed"
        return f"'{self._title}' by {self._author} ({self._year}) - {status}"


class Ebook(Book):
    def __init__(self, title, author, year, filesize):
        super().__init__(title, author, year)
        self.filesize = filesize  # in MB

    def __str__(self):
        return f"[Ebook] {super().__str__()} | File Size: {self.filesize}MB"


class Magazine(Book):
    def __init__(self, title, author, year, issue):
        super().__init__(title, author, year)
        self.issue = issue

    def __str__(self):
        return f"[Magazine] {super().__str__()} | Issue: {self.issue}"