# weather_data.py
import requests
from typing import List, Dict, Any
from dataclasses import dataclass
from datetime import datetime
import json
import csv
from concurrent.futures import ThreadPoolExecutor

API_KEY = "de239557fc4e57c7649d96332e2f3ca7"  # <-- Uzupełnij swoim kluczem API

@dataclass
class WeatherData:
    city: str
    temperature: float
    humidity: int
    timestamp: str

    def to_dict(self) -> dict:
        return {
            "city": self.city,
            "temperature": self.temperature,
            "humidity": self.humidity,
            "timestamp": self.timestamp
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'WeatherData':
        return cls(
            city=data["city"],
            temperature=data["temperature"],
            humidity=data["humidity"],
            timestamp=data["timestamp"]
        )

def fetch_weather(city: str) -> WeatherData:
    print(f"Pobieranie danych z API dla {city}...")
    url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric&lang=pl"
    response = requests.get(url)
    data: Dict[str, Any] = response.json()

    # Check if the API request was successful
    if response.status_code != 200:
        print(f"Error fetching weather data for {city}: {data.get('message', 'Unknown error')}")
        # Return a default WeatherData object with error indicators or raise an exception
        return WeatherData(city=city, temperature=20, humidity=-50, timestamp=datetime.now().isoformat())
    temperature = data["main"]["temp"]
    humidity = data["main"]["humidity"]
    return WeatherData(
        city=city,
        temperature=temperature,
        humidity=humidity,
        timestamp=datetime.now().isoformat()
    )


def fetch_all_weather(cities: List[str]) -> List[WeatherData]:
    with ThreadPoolExecutor() as executor:
        return list(executor.map(fetch_weather, cities))

def save_weather_data(data: List[WeatherData], filename: str):
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump([entry.to_dict() for entry in data], f, indent=2)

def load_weather_data(filename: str) -> List[WeatherData]:
    with open(filename, 'r', encoding='utf-8') as f:
        raw = json.load(f)
        return [WeatherData.from_dict(item) for item in raw]

def save_weather_to_csv(data: List[WeatherData], filename: str):
    with open(filename, mode='w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(["City", "Temperature", "Humidity", "Timestamp"])
        for entry in data:
            writer.writerow([entry.city, entry.temperature, entry.humidity, entry.timestamp])

def display_weather_data(data: List[WeatherData], min_temp: float = None):
    for entry in data:
        if min_temp is None or entry.temperature > min_temp:
            print(f"Miasto: {entry.city} | Temp: {entry.temperature}°C | Wilgotność: {entry.humidity}% | Data: {entry.timestamp}")

def main():
    cities = ["Kraków", "Warszawa", "Gdańsk", "Wrocław", "Poznań"]
    json_file = "weather_data.json"
    csv_file = "weather_data.csv"
    min_temp = 15.0

    print("\nPobieram dane pogodowe...")
    data = fetch_all_weather(cities)

    print("\nZapisuję dane do pliku JSON...")
    save_weather_data(data, json_file)

    print("\nZapisuję dane do pliku CSV...")
    save_weather_to_csv(data, csv_file)

    print(f"\nDane pogodowe z temperaturą powyżej {min_temp}°C:")
    display_weather_data(data, min_temp=min_temp)

if __name__ == "__main__":
    main()
