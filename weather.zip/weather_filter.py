# weather_data.py
from dataclasses import dataclass
from datetime import datetime
import json
import random
import time
from concurrent.futures import ThreadPoolExecutor
from typing import List
import argparse

@dataclass
class WeatherData:
    city: str
    temperature: float
    humidity: int
    timestamp: str

    def to_dict(self) -> dict:
        return {
            "city": self.city,
            "temperature": self.temperature,
            "humidity": self.humidity,
            "timestamp": self.timestamp
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'WeatherData':
        return cls(
            city=data["city"],
            temperature=data["temperature"],
            humidity=data["humidity"],
            timestamp=data["timestamp"]
        )

def fetch_weather(city: str) -> WeatherData:
    print(f"Pobieranie danych dla {city}...")
    time.sleep(random.uniform(0.5, 2.0))
    temperature = round(random.uniform(-5, 30), 1)
    humidity = random.randint(30, 90)
    return WeatherData(
        city=city,
        temperature=temperature,
        humidity=humidity,
        timestamp=datetime.now().isoformat()
    )

def fetch_all_weather(cities: List[str]) -> List[WeatherData]:
    with ThreadPoolExecutor() as executor:
        return list(executor.map(fetch_weather, cities))

def save_weather_data(data: List[WeatherData], filename: str):
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump([entry.to_dict() for entry in data], f, indent=2)

def load_weather_data(filename: str) -> List[WeatherData]:
    with open(filename, 'r', encoding='utf-8') as f:
        raw = json.load(f)
        return [WeatherData.from_dict(item) for item in raw]

def display_weather_data(data: List[WeatherData]):
    for entry in data:
        print(f"Miasto: {entry.city} | Temp: {entry.temperature}°C | Wilgotność: {entry.humidity}% | Data: {entry.timestamp}")

def filter_by_temperature(data: List[WeatherData], min_temp: float) -> List[WeatherData]:
    return [entry for entry in data if entry.temperature >= min_temp]

def main():
    parser = argparse.ArgumentParser(description="System pobierania danych pogodowych")
    parser.add_argument('--min-temp', type=float, help="Minimalna temperatura do filtrowania wyników")
    parser.add_argument('--only-load', action='store_true', help="Tylko wczytaj dane z pliku i wyświetl")
    parser.add_argument('--filename', type=str, default='weather_data.json', help="Nazwa pliku z danymi")
    args = parser.parse_args()

    filename = args.filename

    if args.only_load:
        print("\nWczytuję dane z pliku...")
        loaded = load_weather_data(filename)
    else:
        cities = ["Kraków", "Warszawa", "Gdańsk", "Wrocław", "Poznań"]
        print("\nPobieram dane pogodowe...")
        data = fetch_all_weather(cities)

        print("\nZapisuję dane do pliku...")
        save_weather_data(data, filename)

        loaded = data

    if args.min_temp is not None:
        print(f"\nFiltrowanie danych dla temperatury >= {args.min_temp}°C")
        loaded = filter_by_temperature(loaded, args.min_temp)

    print("\nDane pogodowe:")
    display_weather_data(loaded)

if __name__ == "__main__":
    main()
