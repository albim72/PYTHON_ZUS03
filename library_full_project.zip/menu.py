from models import Library, Book
from storage import save_to_json, load_from_json, save_to_csv, load_from_csv
from visualization import plot_ages
from datetime import datetime


def menu():
    library = Library()
    while True:
        print("\n📚 === MENU BIBLIOTEKI === 📚")
        print("1. Dodaj książkę")
        print("2. Wyświetl wszystkie książki")
        print("3. Zapisz bibliotekę do JSON")
        print("4. Wczytaj bibliotekę z JSON")
        print("5. Zapisz bibliotekę do CSV")
        print("6. Wczytaj bibliotekę z CSV")
        print("7. Wygeneruj i zapisz wykres wieku książek")
        print("8. Filtrowanie książek po dacie wydania")
        print("9. Sortowanie książek po dacie wydania")
        print("0. Wyjście z programu")

        choice = input("Wybierz opcję: ")

        if choice == '1':
            title = input("Tytuł książki: ")
            author = input("Autor książki: ")
            date_str = input("Data wydania (YYYY-MM-DD): ")
            try:
                library.add_book(Book(title, author, date_str))
                print("✅ Książka została dodana.")
            except ValueError:
                print("❌ Nieprawidłowy format daty.")

        elif choice == '2':
            library.show_books()

        elif choice == '3':
            save_to_json(library, "library.json")
            print("✅ Zapisano do 'library.json'")

        elif choice == '4':
            load_from_json(library, "library.json")
            print("✅ Wczytano dane z 'library.json'")

        elif choice == '5':
            save_to_csv(library, "library.csv")
            print("✅ Zapisano do 'library.csv'")

        elif choice == '6':
            load_from_csv(library, "library.csv")
            print("✅ Wczytano dane z 'library.csv'")

        elif choice == '7':
            plot_ages(library)

        elif choice == '8':
            start = input("Podaj datę początkową (YYYY-MM-DD): ")
            end = input("Podaj datę końcową (YYYY-MM-DD): ")
            try:
                start_date = datetime.strptime(start, "%Y-%m-%d").date()
                end_date = datetime.strptime(end, "%Y-%m-%d").date()
                library.filter_by_date_range(start_date, end_date)
            except ValueError:
                print("❌ Błąd formatu daty.")

        elif choice == '9':
            sort_order = input("Sortowanie (1 - rosnąco, 2 - malejąco): ")
            if sort_order == '1':
                library.sort_by_date(reverse=False)
            elif sort_order == '2':
                library.sort_by_date(reverse=True)
            else:
                print("❌ Nieprawidłowy wybór sortowania.")

        elif choice == '0':
            print("👋 Dziękujemy za skorzystanie z biblioteki!")
            break
        else:
            print("❌ Nieprawidłowa opcja, spróbuj ponownie.")
