import matplotlib.pyplot as plt

def plot_ages(library):
    if not library.books:
        print("Brak książek do wykresu.")
        return

    titles = [book.title for book in library.books]
    ages = [book.age() for book in library.books]
    colors = ['#8e44ad', '#3498db', '#27ae60', '#e67e22', '#c0392b']

    plt.figure(figsize=(12, 7))
    bars = plt.bar(titles, ages, color=colors[:len(titles)])

    for bar, age in zip(bars, ages):
        plt.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 1, f'{age} lat',
                 ha='center', va='bottom', fontsize=10, color='black', fontweight='bold')

    plt.xlabel('Tytuł książki', fontsize=12)
    plt.ylabel('Wiek książki (lata)', fontsize=12)
    plt.title('Wiek książek w bibliotece', fontsize=14, fontweight='bold')
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()

    plt.savefig('book_ages_chart.png', dpi=300)
    print("✅ Wykres zapisano do 'book_ages_chart.png'")
    plt.show()
