import unittest
from datetime import date
from models import Book, Library

class TestBook(unittest.TestCase):
    def test_book_creation(self):
        book = Book("Test Title", "Test Author", "2000-01-01")
        self.assertEqual(book.title, "Test Title")
        self.assertEqual(book.author, "Test Author")
        self.assertEqual(book.published_date, date(2000, 1, 1))

    def test_book_age(self):
        book = Book("Old Book", "Author", "1990-01-01")
        expected_age = date.today().year - 1990
        self.assertEqual(book.age(), expected_age)

class TestLibrary(unittest.TestCase):
    def setUp(self):
        self.library = Library()
        self.book1 = Book("Book One", "Author A", "2000-01-01")
        self.book2 = Book("Book Two", "Author B", "2010-05-15")
        self.library.add_book(self.book1)
        self.library.add_book(self.book2)

    def test_add_book(self):
        self.assertEqual(len(self.library.books), 2)

    def test_filter_by_date_range(self):
        start = date(1999, 1, 1)
        end = date(2005, 12, 31)
        result = [b.title for b in self.library.books if start <= b.published_date <= end]
        self.assertIn("Book One", result)
        self.assertNotIn("Book Two", result)

    def test_sort_by_date(self):
        self.library.sort_by_date(reverse=False)
        self.assertEqual(self.library.books[0].title, "Book One")
        self.library.sort_by_date(reverse=True)
        self.assertEqual(self.library.books[0].title, "Book Two")

if __name__ == '__main__':
    unittest.main()
