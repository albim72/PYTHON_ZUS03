from datetime import datetime, date

class Book:
    def __init__(self, title, author, published_date):
        self.title = title
        self.author = author
        if isinstance(published_date, str):
            self.published_date = datetime.strptime(published_date, "%Y-%m-%d").date()
        else:
            self.published_date = published_date

    def age(self):
        return date.today().year - self.published_date.year

    def to_dict(self):
        return {
            "title": self.title,
            "author": self.author,
            "published_date": self.published_date.strftime("%Y-%m-%d")
        }

    @staticmethod
    def from_dict(data):
        return Book(data['title'], data['author'], data['published_date'])

    def __str__(self):
        return f'"{self.title}" — {self.author} ({self.published_date.strftime("%Y-%m-%d")}) — {self.age()} lat'


class Library:
    def __init__(self):
        self.books = []

    def add_book(self, book):
        self.books.append(book)

    def show_books(self):
        if not self.books:
            print("Brak książek w bibliotece.")
        for book in self.books:
            print(book)

    def filter_by_date_range(self, start_date, end_date):
        filtered = [
            book for book in self.books
            if start_date <= book.published_date <= end_date
        ]
        if not filtered:
            print("Brak książek w podanym przedziale dat.")
        for book in filtered:
            print(book)

    def sort_by_date(self, reverse=False):
        self.books.sort(key=lambda book: book.published_date, reverse=reverse)
        print("✅ Posortowano książki.")
        self.show_books()
