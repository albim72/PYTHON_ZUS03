import json
import csv
from models import Book

def save_to_json(library, filename):
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump([book.to_dict() for book in library.books], f, ensure_ascii=False, indent=4)

def load_from_json(library, filename):
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            data = json.load(f)
            library.books = [Book.from_dict(book) for book in data]
    except FileNotFoundError:
        print("Plik JSON nie istnieje.")

def save_to_csv(library, filename):
    with open(filename, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(["title", "author", "published_date"])
        for book in library.books:
            writer.writerow([book.title, book.author, book.published_date.strftime("%Y-%m-%d")])

def load_from_csv(library, filename):
    try:
        with open(filename, mode='r', newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            library.books = [
                Book(row['title'], row['author'], row['published_date'])
                for row in reader
            ]
    except FileNotFoundError:
        print("Plik CSV nie istnieje.")
