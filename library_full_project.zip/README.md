
#  Python Library Management App

Prosta aplikacja konsolowa do zarządzania biblioteką książek. Pozwala na dodawanie książek, filtrowanie, sortowanie, wizualizację wieku książek oraz zapis i odczyt danych z plików JSON i CSV.

---

##  Funkcje aplikacji:
- Dodawanie książek z datą wydania
- Wyświetlanie książek wraz z wiekiem
- Zapis i odczyt biblioteki w formacie **JSON** i **CSV**
- Generowanie i zapisywanie wykresu wieku książek (**PNG**)
- Filtrowanie książek po przedziale dat
- Sortowanie książek po dacie wydania
- Prosty interfejs tekstowy (menu w terminalu)

---

## 📂 Struktura projektu:
```
library_project/
│
├── main.py              # Punkt startowy aplikacji
├── menu.py              # Logika interfejsu tekstowego (menu użytkownika)
├── models.py            # Definicje klas Book i Library
├── storage.py           # Operacje na plikach JSON i CSV
├── visualization.py     # Generowanie i zapis wykresu
└── README.md            # Dokumentacja projektu
```

---

## 📜 Opis plików:

### `main.py`
- Punkt wejścia aplikacji
- Uruchamia funkcję menu z `menu.py`

### `menu.py`
- Logika menu i interfejs użytkownika w terminalu
- Obsługuje:
  - dodawanie książki
  - zapis/odczyt JSON
  - zapis/odczyt CSV
  - generowanie i zapis wykresu
  - filtrowanie książek po dacie
  - sortowanie książek po dacie wydania

### `models.py`
- Klasa **Book**:
  - Przechowuje tytuł, autora i datę wydania
  - Oblicza wiek książki
  - Udostępnia konwersję do słownika
- Klasa **Library**:
  - Zarządza kolekcją książek
  - Filtrowanie po dacie
  - Sortowanie książek po dacie wydania
  - Wyświetlanie książek

### `storage.py`
- Zapis i odczyt danych biblioteki do/z:
  - **JSON**
  - **CSV**
- Odpowiada za pracę z plikami

### `visualization.py`
- Generuje wykres wieku książek
- Zapisuje wykres do pliku `book_ages_chart.png`
- Obsługuje wizualizację w matplotlib

### `README.md`
- Dokumentacja projektu
- Instrukcja obsługi i opis plików

---

## 🛠 Jak uruchomić aplikację:
### 1. Instalacja wymaganych bibliotek:
```bash
pip install matplotlib
```

### 2. Uruchomienie aplikacji:
```bash
python main.py
```

---

## 📈 Efekty działania:
- `library.json` — zapis książek w formacie JSON
- `library.csv` — eksport kolekcji do pliku CSV
- `book_ages_chart.png` — wygenerowany wykres wieku książek
- Filtrowanie i sortowanie wyświetlane w konsoli

---

##  Możliwości rozwoju:
✅ Eksport do PDF  
✅ Integracja z bazą danych SQLite  
✅ GUI w `Tkinter` lub `PyQt`  
✅ Testy jednostkowe (`pytest`)  
✅ Rozbudowa API REST

---

##  Autor:
Projekt stworzony jako przykład aplikacji edukacyjnej dla studentów:
- nauka programowania obiektowego w Pythonie
- praca z plikami JSON i CSV
- wizualizacja danych
- budowa modularnej aplikacji CLI
