# gui.py

import tkinter as tk
from tkinter import messagebox, ttk
from race import Runner, create_race

race = create_race("City Marathon 2025")

def add_runner_gui():
    try:
        name = entry_name.get().strip()
        surname = entry_surname.get().strip()
        birth_year = int(entry_birth.get())
        start_number = int(entry_start.get())
        time = int(entry_time.get())

        if not name or not surname:
            raise ValueError("Imię i nazwisko nie mogą być puste.")

        runner = Runner(name, surname, birth_year, start_number, time)
        race.add_runner(runner)
        messagebox.showinfo("Sukces", f"Zawodnik {name} {surname} dodany!")
        clear_entries()
    except ValueError as e:
        messagebox.showerror("Błąd", f"Nieprawidłowe dane: {e}")

def clear_entries():
    entry_name.delete(0, tk.END)
    entry_surname.delete(0, tk.END)
    entry_birth.delete(0, tk.END)
    entry_start.delete(0, tk.END)
    entry_time.delete(0, tk.END)

def show_average_time():
    avg = race.average_time()
    messagebox.showinfo("Średni czas", f"Średni czas: {avg:.2f} minut")

def save_results():
    race.save_to_json("results.json")
    messagebox.showinfo("Zapisano", "Wyniki zapisano do results.json")

def load_runners():
    try:
        race.load_from_json("runners.json")
        messagebox.showinfo("Wczytano", "Zawodnicy wczytani z runners.json")
    except Exception as e:
        messagebox.showerror("Błąd", f"Nie można wczytać: {e}")

def show_categories():
    cats = race.runners_by_category()
    output = ""
    for cat, runners in cats.items():
        output += f"{cat}:\n"
        for r in runners:
            output += f"  {r.name} {r.surname} ({r.birth_year})\n"
    messagebox.showinfo("Kategorie wiekowe", output)

def show_sorted_results():
    if not race.runners:
        messagebox.showwarning("Brak danych", "Brak zawodników w wyścigu.")
        return

    sorted_runners = sorted(race.runners, key=lambda r: r.time)
    output = "Wyniki (od najlepszego):\n"
    for idx, r in enumerate(sorted_runners, 1):
        output += f"{idx}. {r.name} {r.surname} - {r.time} min\n"

    messagebox.showinfo("Wyniki", output)

def show_table():
    if not race.runners:
        messagebox.showwarning("Brak danych", "Brak zawodników do wyświetlenia.")
        return

    table_win = tk.Toplevel(root)
    table_win.title("Tabela zawodników")

    cols = ("Imię", "Nazwisko", "Rok urodz.", "Nr startowy", "Czas [min]", "Kategoria")
    tree = ttk.Treeview(table_win, columns=cols, show="headings")
    for col in cols:
        tree.heading(col, text=col)
        tree.column(col, anchor="center")

    for r in race.runners:
        tree.insert("", "end", values=(
            r.name, r.surname, r.birth_year, r.start_number, r.time, r.get_age_category(2025)
        ))

    tree.pack(expand=True, fill="both", padx=10, pady=10)

# --- GUI ---
root = tk.Tk()
root.title("Zawody biegowe")

# Pola wejściowe
tk.Label(root, text="Imię").grid(row=0, column=0)
entry_name = tk.Entry(root)
entry_name.grid(row=0, column=1)

tk.Label(root, text="Nazwisko").grid(row=1, column=0)
entry_surname = tk.Entry(root)
entry_surname.grid(row=1, column=1)

tk.Label(root, text="Rok urodzenia").grid(row=2, column=0)
entry_birth = tk.Entry(root)
entry_birth.grid(row=2, column=1)

tk.Label(root, text="Numer startowy").grid(row=3, column=0)
entry_start = tk.Entry(root)
entry_start.grid(row=3, column=1)

tk.Label(root, text="Czas (minuty)").grid(row=4, column=0)
entry_time = tk.Entry(root)
entry_time.grid(row=4, column=1)

# Przyciski
tk.Button(root, text="Dodaj zawodnika", command=add_runner_gui).grid(row=5, column=0, columnspan=2, pady=5)
tk.Button(root, text="Średni czas", command=show_average_time).grid(row=6, column=0, columnspan=2)
tk.Button(root, text="Pokaż kategorie", command=show_categories).grid(row=7, column=0, columnspan=2)
tk.Button(root, text="Wyniki (sortuj)", command=show_sorted_results).grid(row=8, column=0, columnspan=2)
tk.Button(root, text="Pokaż tabelę", command=show_table).grid(row=9, column=0, columnspan=2)
tk.Button(root, text="Zapisz do JSON", command=save_results).grid(row=10, column=0, columnspan=2)
tk.Button(root, text="Wczytaj z JSON", command=load_runners).grid(row=11, column=0, columnspan=2)

root.mainloop()
