# race.py

import json
from datetime import datetime

class Runner:
    def __init__(self, name, surname, birth_year, start_number, time):
        self.name = name
        self.surname = surname
        self.birth_year = birth_year
        self.start_number = start_number
        self.time = time

    @staticmethod
    def calculate_age(current_year, birth_year):
        return current_year - birth_year

    def get_age_category(self, current_year):
        age = Runner.calculate_age(current_year, self.birth_year)
        if age < 30:
            return "Młodzież"
        elif age < 50:
            return "Dorośli"
        else:
            return "Seniorzy"

    def to_dict(self):
        return {
            "name": self.name,
            "surname": self.surname,
            "birth_year": self.birth_year,
            "start_number": self.start_number,
            "time": self.time,
            "category": self.get_age_category(datetime.now().year)
        }


def create_race(name):
    class Race:
        def __init__(self):
            self.name = name
            self.runners = []

        def add_runner(self, runner):
            if runner.time < 0:
                raise ValueError("Czas nie może być ujemny.")
            self.runners.append(runner)

        def average_time(self):
            if not self.runners:
                return 0
            return sum(r.time for r in self.runners) / len(self.runners)

        def runners_by_category(self):
            categories = {"Młodzież": [], "Dorośli": [], "Seniorzy": []}
            for r in self.runners:
                cat = r.get_age_category(datetime.now().year)
                categories[cat].append(r)
            return categories

        def save_to_json(self, filename):
            data = [runner.to_dict() for runner in self.runners]
            with open(filename, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4, ensure_ascii=False)

        def load_from_json(self, filename):
            with open(filename, "r", encoding="utf-8") as f:
                data = json.load(f)
                for r in data:
                    runner = Runner(
                        r["name"], r["surname"], r["birth_year"],
                        r["start_number"], r["time"]
                    )
                    self.add_runner(runner)

    return Race()
