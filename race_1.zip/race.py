# race.py

import json
from datetime import datetime

class Runner:
    def __init__(self, name, surname, birth_year, start_number, time):
        self.name = name
        self.surname = surname
        self.birth_year = birth_year
        self.start_number = start_number
        self.time = time  # czas w minutach

    @staticmethod
    def calculate_age(current_year, birth_year):
        return current_year - birth_year

    def to_dict(self):
        return {
            "name": self.name,
            "surname": self.surname,
            "birth_year": self.birth_year,
            "start_number": self.start_number,
            "time": self.time
        }


def create_race(name):
    class Race:
        def __init__(self):
            self.name = name
            self.runners = []

        def add_runner(self, runner):
            if runner.time < 0:
                raise ValueError("Czas nie może być ujemny.")
            self.runners.append(runner)

        def average_time(self):
            if not self.runners:
                return 0
            total_time = sum(r.time for r in self.runners)
            return total_time / len(self.runners)

        def save_to_json(self, filename):
            data = [runner.to_dict() for runner in self.runners]
            with open(filename, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4, ensure_ascii=False)

    return Race()
