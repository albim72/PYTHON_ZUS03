# main.py

from race import Runner, create_race

def main():
    race = create_race("City Marathon 2025")

    # Dodaj zawodników
    runner1 = Runner("John", "Doe", 1990, 101, 240)
    runner2 = Runner("Anna", "Smith", 1985, 102, 230)
    runner3 = Runner("Piotr", "Nowak", 1995, 103, 250)

    race.add_runner(runner1)
    race.add_runner(runner2)
    race.add_runner(runner3)

    # Oblicz średni czas
    avg_time = race.average_time()
    print(f"Średni czas ukończenia biegu: {avg_time:.2f} minut")

    # Zapisz dane do JSON
    race.save_to_json("results.json")
    print("Dane zapisano do pliku results.json")

if __name__ == "__main__":
    main()
